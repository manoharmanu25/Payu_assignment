import React from 'react';
import FilterClass from './Filter.module.css'
const Filters = (props)=>{
    return (
        <div className={FilterClass.Filter}>
           <input className={FilterClass.SearchInput} type="text" placeholder="Search" onChange={props.onFilter}/>  
            <div className={FilterClass.checkbox_widget}>
               <input type="checkbox" value="Select" defaultChecked={props.selected} onChange={props.onSelectChange}/>
              <label>Show Selected</label>
            </div>
            
        </div>
    )
}
export default Filters;