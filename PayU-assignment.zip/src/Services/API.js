import axios from "axios"
const fetchAll= ()=>{
    return axios.get("https://lpcontent.s3.ap-south-1.amazonaws.com/Test/API.json");
}
export default fetchAll;