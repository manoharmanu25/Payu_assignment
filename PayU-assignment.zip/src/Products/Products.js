import React, { Component,Fragment } from "react";
import fetchAll from "../Services/API";
import Filters from "../Filters/Filter";
import ProductTable from "./ProductTable/ProductTable"
class Products extends Component {
  state = {
    products: [],
    showSelected: false,
    isFilter:false,
    search:""
  };
  componentDidMount() {
    fetchAll().then((response) => {
      this.setState({
        products: response.data.config,
      });
    });
  }
  selectHandler=(e)=>{
      this.setState({
          showSelected: e.target.checked
      })
  }
  filterHandler=(e)=>{
    this.setState({
        isFilter: (e.target.value === "")?false:true,
        search:e.target.value.toLowerCase()

    })
}
  render() {
     // console.log(this.state.search)
    return (
      <Fragment>
        <Filters selected={this.state.showSelected} onSelectChange={this.selectHandler}
        onFilter={this.filterHandler} />
        <ProductTable products = {this.state.products} selected={this.state.showSelected}
             isFilter={this.state.isFilter}    search = {this.state.search}    
        />
      </Fragment>
    );
  }
}
export default Products;
