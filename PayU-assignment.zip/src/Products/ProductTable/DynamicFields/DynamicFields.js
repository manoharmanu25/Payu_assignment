import React from 'react';
const DynamicFields = (props)=>{
    let input = null;
    switch (props.fields.type) {
        case "text":
            input = <input type="text" defaultValue={props.fields.defaultValue ==="" ?"String":props.fields.defaultValue}/>
            break;
        case "select":
            input = <select defaultValue={props.fields.defaultValue}>
               { props.fields.options.map((o,i)=>{
                  return <option key={o} value={o}>{o}</option>
               })}
            </select>
        break;
        default:
            input = null;
            break;
    }

    
    
    return (input)
}
export default DynamicFields