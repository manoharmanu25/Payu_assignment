import React from "react";
import classes from "./ProductTable.module.css";
import DynamicFields from "./DynamicFields/DynamicFields";
const ProductTable = ({ products, selected, isFilter, search }) => {
  const productslist =
    selected === true ? products.filter((p) => p.selected) : products;
  //console.log(isFilter)
  const filteredProduct =
    isFilter === true
      ? productslist.filter((p) => {
          // console.log(p.label);
          if (p.label.match(new RegExp(search, "img")) !== null) {
            return p;
          }
        })
      : productslist;
  //  console.log(filteredProduct)
  return filteredProduct.length > 0 ? 
    <table>
      <thead>
        <tr>
          <th scope="col"></th>
          <th scope="col">Key</th>
          <th scope="col">Value</th>
          <th scope="col">Description</th>
        </tr>
      </thead>
      <tbody>
        {filteredProduct.map((product, i) => {
          return (
            <tr key={`${products.key}_${i}`}>
              <td>
                <input
                  type="checkbox"
                  defaultChecked={product.selected}
                ></input>
              </td>
              <td>
                <label>{product.label}</label>
              </td>
              <td>
                <DynamicFields fields={product.field} />
              </td>
              <td>
                <p>{product.description}</p>
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  : <div className={classes.alert}>Sorry,no products in the list your looking for!&#129402;
  </div>;
};

export default ProductTable;
